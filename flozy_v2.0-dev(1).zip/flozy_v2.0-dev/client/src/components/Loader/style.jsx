const Style = () => ({
  '.loader': {
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  '.loaderText': {
    fontWeight: "bold",
    marginBottom: '8px'
  },
});

export default Style;
