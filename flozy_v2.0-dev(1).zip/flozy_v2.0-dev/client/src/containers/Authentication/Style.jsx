const Style = {
    loginContainer: {
        width: '100%',
        maxWidth: '480px',
        padding: '21px'
    }
}
export default Style;
