const initialValue = [
  { type: "paragraph", children: [{ text: "" }] },
  {
    type: "grid",
    grid: "container",
    children: [
      {
        type: "grid-item",
        grid: 12,
        children: [
          { type: "paragraph", children: [{ text: "" }] },
          {
            type: "image",
            alt: "",
            url: "https://img.freepik.com/free-vector/stylish-glowing-digital-red-lines-banner_1017-23964.jpg",
            children: [{ text: "" }],
            size: { width: 438, height: 100, widthInPercent: 100 },
          },
          { type: "paragraph", children: [{ text: "" }] },
          {
            type: "alignCenter",
            children: [
              {
                type: "paragraph",
                children: [
                  { text: "Sample Links", fontSize: "huge", bold: true },
                ],
              },
            ],
          },
          {
            type: "alignCenter",
            children: [
              {
                type: "paragraph",
                children: [
                  {
                    fontSize: "huge",
                    text: "It is a long established fact that a reader will be",
                  },
                ],
              },
              {
                type: "paragraph",
                children: [
                  {
                    fontSize: "huge",
                    text: " Various versions have evolved over the years, ",
                  },
                ],
              },
              {
                type: "paragraph",
                children: [
                  {
                    fontSize: "huge",
                    text: "sometimes by accident, sometimes on ",
                  },
                ],
              },
              {
                type: "paragraph",
                children: [
                  {
                    fontSize: "huge",
                    text: "purpose (injected humour and the like).",
                  },
                ],
              },
            ],
          },
          {
            type: "grid",
            grid: "container",
            children: [
              {
                type: "grid-item",
                grid: 3,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "image",
                    alt: "",
                    url: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80",
                    children: [{ text: "" }],
                  },
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "grid",
                    grid: "container",
                    children: [
                      {
                        type: "grid-item",
                        grid: 12,
                        children: [
                          {
                            type: "paragraph",
                            children: [
                              {
                                text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
                              },
                              { text: "Lorem Ipsum ", bold: true },
                              {
                                text: "has been the industry's standard dummy text ever since the 1500s",
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
              {
                type: "grid-item",
                grid: 3,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "image",
                    alt: "",
                    url: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80",
                    children: [{ text: "" }],
                  },
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "grid",
                    grid: "container",
                    children: [
                      {
                        type: "grid-item",
                        grid: 12,
                        children: [
                          {
                            type: "paragraph",
                            children: [
                              { text: "Lorem Ipsum", bold: true },
                              {
                                text: " is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ",
                              },
                              {
                                text: "dummy text ever since the 1500s",
                                bold: false,
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
              {
                type: "grid-item",
                grid: 3,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "image",
                    alt: "",
                    url: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80",
                    children: [{ text: "" }],
                  },
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "grid",
                    grid: "container",
                    children: [
                      {
                        type: "grid-item",
                        grid: 12,
                        children: [
                          {
                            type: "paragraph",
                            children: [
                              { text: "Lorem Ipsum", bold: true },
                              {
                                text: " is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
              {
                type: "grid-item",
                grid: 3,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "image",
                    alt: "",
                    url: "https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aHVtYW58ZW58MHx8MHx8fDA%3D&w=1000&q=80",
                    children: [{ text: "" }],
                  },
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "grid",
                    grid: "container",
                    children: [
                      {
                        type: "grid-item",
                        grid: 12,
                        children: [
                          {
                            type: "paragraph",
                            children: [
                              {
                                text: "Lorem Ipsum is simply dummy text of the ",
                              },
                              { text: "printing and typesetting ", bold: true },
                              {
                                text: "industry. Lorem Ipsum has been the industry's standard dummy text",
                              },
                            ],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      {
        type: "grid-item",
        grid: 12,
        children: [
          {
            type: "alignCenter",
            children: [
              {
                type: "paragraph",
                children: [
                  { text: "Table Datas", fontSize: "huge", bold: true },
                ],
              },
            ],
          },
          {
            type: "alignLeft",
            children: [
              {
                type: "paragraph",
                children: [{ fontSize: "huge", bold: true, text: "" }],
              },
            ],
          },
          {
            type: "grid",
            grid: "container",
            children: [
              {
                type: "grid-item",
                grid: 6,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "alignCenter",
                    children: [
                      {
                        type: "paragraph",
                        children: [
                          { text: "Pie Chart", fontSize: "medium", bold: true },
                        ],
                      },
                      {
                        type: "paragraph",
                        children: [
                          { fontSize: "medium", bold: true, text: "" },
                        ],
                      },
                      {
                        type: "image",
                        alt: "",
                        url: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBAPEA8VEBAVEBIVFxYVFxUVEBUWFhUWFhYVFxUYHSgiGBolGxUVITEhJikrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGi0lICUtLS0tLSstLS0rLS0tLS0tLS0tLSstKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALEBHAMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABQECAwQGBwj/xABHEAABAwIBCAYGBggFBQEAAAABAAIDBBEFBhIhMUFRYXEiMoGRobEjQmJyksEHExRSgtEVM1OTorLC4UNUc4PSFiREY9M0/8QAGwEAAQUBAQAAAAAAAAAAAAAAAAECAwQFBgf/xAA6EQACAQICBggEBQIHAAAAAAAAAQIDEQQxBRIhQVFhE3GBkaGx0fAGIkLBFDIzUuGi0iNDU3KCkuL/2gAMAwEAAhEDEQA/APcUREAEREAEREAEREAERRldjdNBokma0/dHSf8AC25SNpZjoQlOWrBNvgtrJNFxFd9IUI0QwufxeQ0dwufJQVXl3WPvm5kQ9ltz3vv5KGWJgjTpaGxc84qPW/ttZ6orHvA1kDnoXjM+P1b+tUS8g9wHcLBR75XON3Ek7zpPioni1uRdh8Py+qouxN+dj22TEqdvWqIm83sHmVj/AEzSf5qH97H+a8Vud5S6b+LfAnXw/T31H3L1Z7V+maX/ADUP7xn5rLHiELurPG7k9p8ivELpp3oWLfASXw/T3VH3L1R7zfcqrwmKoezSx5byJHkpGnylrWG4qZD7xzx3PunrFreiCfw/P6ai7U15ax7Ki8xpMvqpo9I2OQb7Fru9pt4Kfw/L2mfYSsfEd+h7O8afBSRxFN7yjV0Ri6f03/2u/hn4HXotOhxGGYXilZJ7pBI5jWO1bimTTyM2UXF2aswiIlECIiACIiACKg0qqACIiACIiACIiACIiACIoTHcoYKRvTOdIR0Y29Y8T90cT2XSNpK7H06c6klCCu3uJh7wASTYDWdi5fGctaeG7YvTv9kgRj8e3sB5rhscyjqKokPdmx30Rt0N7d54nwUQqVTFN7IHSYTQUV82Id+Sy7Xv7LdZN4plVVT3BkMbPux9BvadZ7SoUlWoqspOTuzep0oUo6sEkuWwqioiQkKoqIgCqKiIAqioiAKoqIgCqKiIAvZIWkOaS0jUQbEciNS6PCstaqKweRO3c7r9jhp77rmUTozlF3TIa2HpV1apFPr+3A9dwbKimqbNDsyQ+o+wJPsnU7s08FPr5+qKpsYu5wHmexdf9GGWU1ZUyUb7vjbA6Rr3aZBmvY219oOft1WV6hWlPY12nM6S0TDDxdSnLZ+159j39veepItSurooGGSaRsbBtcbdg3ngF5/j/wBIb3Xjo25jdX1rx0z7rdTeZvyC08Ng62If+GtnHcvfK5z86kYZnbYzjtPSNzppACRoYNMjuTfnqXnGUGXVTUXZDeni9k+lcOLxq5DvK5eaZz3F73F7yblziS48yVYulwmiKNG0pfNLnl2L7vaU515Sy2IksExyejfnxPsCek06Y3+8N/HWvV8m8pIa1nR6EoHSjJ6Q4g+s3j32Xiyshxb6h7ZIpSJGm4LNJB7NHYVJj9HU8Sr5S4+vHrzQlKq4bNx9FIoDIzG3V1FFUuZmPJe1wGkZzHFtxwNr22Xsp9cdODhJxlmnYvp3VwiImihERABEXJ5aZRilZ9TE707x+7afW947O/m2c1FXZNh6E69RU4LayzK3KxtPeGEh03rO1tj/ADdw2bdy82nmc9xe9xc5xuSTck7yVY4k6SbnjrPFUWZUqObuzt8FgqeFhqwz3ve/45BERRlwIiIAIiIAIiIAIiIAIiIAIiIAIhNlD4jj0cdw3pv/AIf7pUm3ZDZSUVeTsiWlka0XcQBxUDiOUQF2xDOO8/ILnq/EpJTdztH3di2sPwaSSznejZvPWPIfmtDC4CdaWqld8Fu63ku0yMXpaFKN07Li/svb5GtJUPkdpJc49vcF2OQlVNh0stSGNL3wOiaHX6Oc9ji4ga+pqvtWCmo4oG3Fm+04i57T5BYKjGoWaiXn2dXefyK67CaFp01ett5LLt4+C6zkcXpOddtQWe95v08+om8SxGapf9ZPI6R3HUBuaBoaOAWqTYXOgbzoHeubqMoJD1Ghg+J3jo8FHPqJZXWJdI7YNLj2BbScYq0VsXAzVTbe06ioxaFnr5x3N0+OrxUbPlA46GMA4nSfyVlHkxVSaSwRje82Pwi571OUeR8LbGWR0h3DoN+Z8QoZ4mK3mnh9DYmrlCy4y2eGfbY59lS+Q9Nxdw2djdSlYMLncOjEbcc1vmuopKKKL9XG1nEDpdrjpKzqlOu5GzQ+Hor9WfZFW8Wn5Hd/RXGW4XBcWJfPfsmePkuvXCZD4zmu+zPPRcSYzucdJb26TzvvXdrmsXFqtK+937zLxOFlhqnRy7HxXEIiKuVwiIgCPxnEWUsEk79IaNA2ucdDWjmSAvGa2qfNI+V5znOcXOPHhwGoDcAux+k3EryR0rToa36x3FzrtaOwZx/EFxCz8TU1pavA6/QmFVOh0rzl5bu/PqsERFWNoIiIAIiIAIiIAIiIAIiIAIrVgq62OIXc63DaeQQIbK0K/FI4tBOc7cPnuUFiGPPfcM6Df4j27FEOudasQoN/mKdXGxjshtfgbuI4vJLovmN3BRZCykLLSUMsxtFE6TkNA5uOgK1GNvlijNqznVfzbTboKqCFod9W58ltbrBrT7Ovv1pUY7K7q2YOGvvOlSVJkdM6xlkbGNGgekd8gO8qdoslqWPTmGV295JHwiw8F21CpCjTUIqy4Jb+fPrMNaGxWIm5zVucnu5JXfZZHCME0zuiHyu4AuPaVMUeSNQ/S8tiHE5zu5ujxXexU5ADWNsNzW2HcFf9Q/7h7iklim8vU1KOgqEP1Za3L8q9fFHN0eSVMzS/OlPE5je5vzJU3T08cYzY2NYNzQB5LYMTtujno81Y4ga3sHN7B5lQyqOWbNajRoUP00l1Wv3597KIrTKzbNF8bP8AkrTVwjXPH8V/JMuiXpIcUZEWF2IUw11LO6Q+TVj/AEpTft29jZP+KNZB0kFvNxjiCCDaxBBGsEaQR2r1XAq8VEEcvrEWcNzx1hyv4WXj/wCk6fZI48mn5kLt/ozxISfaYm52a0seC4AG7gWu0An7jVRxyjKF1mvIyNLxhUo66e2L8Hs9Oy53iIiyDmQiIgDxXKap+trap5N/TPYOUdoxb4b9qi1nlYXPleS0XllN3OaPXN+sQsbmNGuWMfjYf5SVjvaz0SklGnGKeSS7kiiK10sA11EfYJT5MVzHRnquc/3Y3O87JCRu2d+5hFmbAT1Yal/+zmjvLlk+ySnVSTHm+Nnm0puvBb13jekjx8l5tGqi3mYZUH/xQz3pWO/lWZuD1J/wqdvN0xPgUx16a+pDHXprf4r7NkWqXUw3BKj9pC3/AGy7+ZZG4DL61UPwwRN8Qm/iaXHwGfiqfFePoQWcN6va0nU0nkCVPjADtq5/wlrPIK7/AKeiPWlmk96U/Kya8XSXHuGvGQ93/ggDA/8AZkcwR5rXqKhkfXe0cM5pd8IJK6R2S9FrdETxMkn/ACXIw5ITVlVPHRtDYI3DpyOcGNuAczOsS469h0WvxdDE05Xu7Jb2RzxyjFyW7js+7Iuux0m4jFvaOvuUJK8uN3Ek8V1FFkhL9sdR1RMDmxukuAHBwBaGlh1EG508LWvq3636Opm6YZ2P4PvG7vFwfBW44rDwdtZe+eRhYnS9PpOjq1LPO2223nkcKGq7MUxWZO1cHXgeB94NL2/ELgdq04YjcaNqsqakrxd+onpTjNa0GmuKaa8DSMROoE8hdTWG1FZFGGRGUNuTYB1tJ3WXX4flQ5oDZI2vA2t6DvDR4KbpsoKZ/rujO54NvibfyC18LCNKWtr+Fvuzkp/FVT6aFv8An/4RwH2vE3avtJ5Ml+TVVrcUd6tV2tmHmF6hEQ8XY4SD2SHeWpFoKRVl8V4j/TXe/wCDy84XibtcUx96/wA1T/pvET/hO7XtHmV6miXXZE/irF7ox/q/uPMGZJV51tA5yN+RKzNyKrDrdGObz8gvSURrMil8TY1/t7n95HnIyFq/2sI/E/8A+aysyBn2zxDlnn+gL0FEazIn8RY9/Uv+q+9zhG5AO21LRyaT81miyCA11BPJlv612qI1mMen9IP/ADP6Yf2nBYvgn2XNtIXB1xpFiCO1dn9EDbGrdwhHjKfkoXLL9Wz/AFP6Cpz6KNDKl298Y7g4/wBSqYj8jOp0fiqmJ0br1XeV2r7FlJWysvA9LBVViicsqziMK0lXLFKUAeXswemLpHGFjnfWyXLhnEnOO9bTMPgb1YYm8o2D5LFBLaoqYzsnlt8ZW5dcdWcteSbebOrjOTitryXEoyJo1NA5ABZM5W3S6iECJdLoAIl0QARLogAiLTxGrETfaOobUDopt2Riq3PmkbTQ9dx0nY0bSeAXZ4ZQMp4mxRjojWdridbjxKj8mMJMDDI8enkF3b2jWGfnx5KaVapO+xGbjK6m9SGS8Xx6ty795GY1hLahoIs2Zlyx20X1tJ+6bDuBUHRVBddjxmyNNnA67hdeoPKDDC7/ALiEelaOkB64HzH9tySMjn9IYRzXSQzWfNeq8jWBWlWYTTy6ZII3n72bZ/xjT4rNSVAkaHBZlYjJp3WwxYTcXrRdny2HO1WSEJ/VyOjO49NvjY+Kh6rJWpZ1c2UeybO7nW8yu7VFoUtKYmH1X69vjn4kTpxPMZY5oT0mvjOy4Le4qQpspallgX/WDc8B3idI7Cu+cARYi43HSFGVWT9LJriDTvZ0fAaPBaVHTq+uLXNbfO3myKVBEVTZVsP6yIt4sOj4XfmpSmxWnk6swB3P6B7zo8VEVWR22KbseP6m/koiqwCqj0mIuG9nS8Bp8FrUdL0amxTXbsfiQSw/I7vNNr6xvGlveNCtXntPWzRO6D3RuGuxLT2qVpsqph+sa2UcRZ3xNse9aUcTHeQOi9x1yKGpspad/Xa+I9jm/IjxUpBUxSfq5WP4Xs74XWKlVSLyGODRlRHNI0EEc9Cse6wJKeMOWyym6jdzr+Dl030Wj0Ep3z27mN/NQeHYM3Ep5Q+RzGssRmZtzckW0gr0XJvA46SIQxlzhckl1s4k7TYDh3KjXmneJ3Oi5KGjo03ndvxuTUAWwscbVkVRkzCwTlZ1gmCQEeS4xKY66cj9s49+n5qZhlD2hw1FQ2VrLVs/EtPexqxYTX5hzXdU+C5jGUrzclubv3/Y6ShK8EuS8jokVAb6QqqgTBERABERABEQoAxzSBrS46gq5M4eZ5PtUo9G0+jB1Fw9bkNnHktOGB1ZOImkiJumRw2DcOJ1D+y7mGJrGtY0BrWgAAagBqChqT2WXv35EGLrdFDUX5nnyXq/LrL0RFXMkIiIFOYxyhNO81EY9E4+kaNTSdvI+fNUjeHAEaiumewOBa4XBBBB1EHWFyVVTGklzNJheegd3A8R4hSwkYGkMJqPpY5PPk+PU34+G0ioCimM0qioiACqqIgDFUU0cgtIxrx7QB81E1WS1M/S3OiPsm7e511OLUxCtbE0uOvYN6mo4irS/Tk11P7ZCOKeaOIxnCDTEekDweFnDmNPmtKIlZ8Uq3SvL3H1lgiXY6PqVJ0U6j2kE4qMrEpSYrNHobI4Dde7fhOhbVXjb5Iy0taD95oLTysDbwCiGhZXdUrRjJoVU4yzR1X0cGz6g8Ih4vXo8Dl579HcfRndve1vcL/1Lv6ZVan5mdDhv0l2+bN9iuVrVcoiwFjlCyK1wSMVHmX0g0ubUMk2Pjt2sOnwLVzC9Ny1w0zUzi0XfGc8bzbrDuv3BeYrIxUNWo3x2++02sJPWppcNnoSeG4kWdF2lvkp5jw4Ag3BXHrZo658Z0G42g6is2rh77Y93vyLqnxOpRatHXMk0A2d906+zetpVGrZjwiIkALQxGdxLYYxnSPIAA3lZ66qEbC469ikclMKLQamUekeOiD6jDt5ny5lMnJJCTnGlDpJdi4v+M2SmC4a2miEY0uOl7vvO2nlsCkFRFVbu7mLKUpScpO7ZVFREg0qioiAKrXraRk0bo3jonvB2EcQs6IElFSVmcdCXwyGnl6w6p2ObsIW6pTGcMFQzR0ZG6WO3HceBUBRVBN2PGbI02IOu4U8JHNYvDOhO30vL09558TbRETyqEVskgaCSbAbTqUFiGOa2xfEfkE6MJTdooVJvIkcQxFkQ06XbAuRxCrdK4ucfySWQuJJNyVgeFo0MOqe15+XUTRhYj6s6veVacqZwLJ77c6Vn1hjLGtINs4EkkaRcbluVGQ9bFpa1szfYNnfC63mV0mAkuiXb5jJ4ecvmSIdgVZeqsk1PJEbSxviPttLR2E6Cs9DRGokjhb6zhc7mjS49y0b7yGMXrW3ndZEUmZSxkjS8l5/Fq/hAXXU7VpUNNmgACwAAHIKTiYqcnd3OghDVikjMFVETSQIiIAwTMuvK8qsHNNMS0eieSW7gdrPy4cl60QozGcMZUROieNB1HaDsI4qvXoqpG2/cWcPX6OV9288dVVuYph0lNIYpBxa71XDePy2LTWO007M201JXRQFSNLjEjdDvSN49bsd+d1HImShGWYqdjp6fEon+vmHc/R/Fq77Lbk6Izj1bXvs71xqOqHNY4BxDTrAJseY2qvPD7Lpj4yu0jqMEoTVzGV49BGdWx7tYbyGs921dsuQwHGvqoYWfVtLcxp2h1yLk35lTcWPQHWCw9jgs6pSm3788vEzcViOknyWxe+LJRFrR4hA7VM3tu3zWwx4OpzXcnA/NRdHLh3bfIr3RVFfmHcqZhR0c+D7mJdFqK7MO5WkW16OZASak/2vuC6CLE+qjb1pGj8Qv4LUlxmnb/iF3utPmbJejlwFuSCgsoMNLv8AuIh6Vo6QHrgfMf23JPlK0dSMniT8h+ajKjHp33GdmDc0W8daljh5kNanGrDUll72lYq+MxiQva0atJ035ayo+rx5o0RtzjvdoHdrPguebLnXPtOHcUstCnhVa8jm1StmbFVWPkN3uJ4bByC10sllbilFWRJZLIorXKpU5kxgBqXCWQWgB/eEbB7O/uUkIObshYxcnZE99HmHGNkkzxb63Nzfdbex7S4+C7VkQWvTw2AAC3o2rZpwUIqKNKENWNjG+na4WcAQdhFwtSmwOmieZI4GMeRYlrQD4KURS3H6qMbYgFeqokHWCIiACIiACtLVciAInGcHiqYzHI2+0EdZp3grzLG8FmpHWeM6MnoyDqngfungvYiFrVNK17S1zQ5pFiCLgjkq1bDxqLmWqGJlS6jxRLLs8byJIu+lOj9m46PwO+R71yM8L43FkjCx49Vwsf7jisupSnTzRrUq0Ki+VmFYqrqO90rOWrDVDoP90+SjeRKs0TWFG8EB/wDUz+ULZWrgn/5oP9Nvkt2ypvNmPNfM+tll1XOKrZW2SOzzGlRK4aiVd9pf993eVZZUsjVjwQXMhqHn1j3lYi8q6ypZGrHgFyhKsWSypZOELLKllkslkCnNUXVP+o/+ZbFlrYd1D77/AOZbRKtnON7WWq17gFu4bhk9SbQx3btedEY/Ft5C67nAckooCJH+ll+8R0W+63Zz1qelh51OSJKdGUzncnslXzES1ALItYYdD3+990cNZ4L0Glpg0AAAACwA0ADctiOBbDGLUpUo01aJfp01BWRbGxZQgVVMShERABERABERABERABERABERAFpatDEMMinbmyxteOI0jiDrB5KRRI0mKpNO5weJZDazTy29iTSOxw0jtuuZxPAaqMOa6nebggFgz2ntbq7bL2Eq0sVWeEpy5dRbp42pHPb1nlGHUjoYo4niz2tAI3HWtgtXoVZhEEul8YJ36nfENKip8k4z1JHs4aHDx0+KzqujZ3bg178CPpU3dnJZqtzV0MuS0w6sjHcwW/mtaTAKof4Yd7rh87KtLB1l9IuuiHsqWUi7Cqkf+O7szT5FYnYfP+wk+FM6Cr+19zC6NKypZb36OqNlPJ3W8yqtweqOqncOZYP6kKhV/a+5hrI0LIpZmTdW71WN5uJPgFtQ5ISHrzgcGN095PyUscHWf099hNdHPlYw65zW3c7cNJ7gu1pskqdvWDpD7TjbubYKYpqCOMWYxrBuaAPJWIaNk/zO3VtGupwPMqDIur6nQa3OJzidh09Uabrp8MyJgZZ0t53e1oj+Aa+2668QhXhq0oYanF3SKcaEE72NWGlDQAAABqA1LO2NZAFVWLEtigVURKKEREAEREAEREAEREAEREAEREAEREAEREAEREAEKIk3gWlWlETBS0qiIgQoiIkHFwV7VREohcFciJyECIiVAEREoBERABERABERABERABERAH//2Q==",
                        children: [{ text: "" }],
                      },
                      { type: "paragraph", children: [{ text: "" }] },
                    ],
                  },
                  {
                    type: "paragraph",
                    children: [
                      {
                        type: "table",
                        children: [
                          {
                            type: "table-row",
                            children: [
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column 1" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column Two" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column 3" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column 4" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column 5" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Column 6" }],
                                  },
                                ],
                              },
                            ],
                          },
                          {
                            type: "table-row",
                            children: [
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Data 1" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Data 2" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Data 3" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Data 4" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [
                                      { text: "Data for big columns" },
                                    ],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "otheres" }],
                                  },
                                ],
                              },
                            ],
                          },
                          {
                            type: "table-row",
                            children: [
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Other data" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "some medium" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "Normal" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [
                                      { text: "another big column data" },
                                    ],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "8/9" }],
                                  },
                                ],
                              },
                              {
                                type: "table-cell",
                                children: [
                                  {
                                    type: "paragraph",
                                    children: [{ text: "" }],
                                  },
                                  {
                                    type: "paragraph",
                                    children: [{ text: "othere" }],
                                  },
                                ],
                              },
                            ],
                          },
                        ],
                        rows: 3,
                        columns: 6,
                      },
                    ],
                  },
                ],
              },
              {
                type: "grid-item",
                grid: 6,
                children: [
                  { type: "paragraph", children: [{ text: "" }] },
                  {
                    type: "paragraph",
                    children: [
                      {
                        text: "Some Description about the table data to check Some Description about the table data to check Some Description about the table data to check Some Description about the table data to check Some Description about the table data to check Some Description about the table data to check Some Description about the table data to check ",
                      },
                    ],
                  },
                  {
                    type: "paragraph",
                    children: [
                      {
                        text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
                      },
                    ],
                  },
                  {
                    type: "paragraph",
                    children: [
                      {
                        text: "Pie charts are very widely used in the business world and the mass media.[3] However, they have been criticized,[4] and many experts recommend avoiding them,[5][6][7][8] as research has shown it is difficult to compare different sections of a given pie chart, or to compare data across different pie charts. Pie charts can be replaced in most cases by other plots such as the bar chart, box plot, dot plot, etc.",
                      },
                    ],
                  },
                  {
                    type: "paragraph",
                    children: [
                      {
                        text: "Pie charts are very widely used in the business world and the mass media.[3] However, they have been criticized,[4] and many experts recommend avoiding them,[5][6][7][8] as research has shown it is difficult to compare different sections of a given pie chart, or to compare data across different pie charts. Pie charts can be replaced in most cases by other plots such as the bar chart, box plot, dot plot, etc.",
                      },
                    ],
                  },
                  {
                    type: "paragraph",
                    children: [
                      {
                        text: "Pie charts are very widely used in the business world and the mass media.[3] However, they have been criticized,[4] and many experts recommend avoiding them,[5][6][7][8] as research has shown it is difficult to compare different sections of a given pie chart, or to compare data across different pie charts. Pie charts can be replaced in most cases by other plots such as the bar chart, box plot, dot plot, etc.",
                      },
                    ],
                  },
                  { type: "paragraph", children: [{ text: "Ending..." }] },
                ],
              },
            ],
          },
          {
            type: "alignCenter",
            children: [
              {
                type: "paragraph",
                children: [{ fontSize: "huge", bold: true, text: "" }],
              },
            ],
          },
        ],
      },
    ],
  },
];

module.exports = initialValue;
