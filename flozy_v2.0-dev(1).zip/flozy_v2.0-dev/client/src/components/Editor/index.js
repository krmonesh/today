import Collaborative from "./CollaborativeEditor";
import CommonEditor from "./CommonEditor";

export const Editor = CommonEditor;
export const CollaborativeEditor = Collaborative;
